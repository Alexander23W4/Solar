# -*- coding: utf-8 -*-
"""
1月15日 24 小时阴影面积变化曲线生成
=================================
读取 "F:\\南极国创\\我的\\测试2.xlsx" 中 "详细数据" 工作表，
筛选 2026-01-15 一天 24 个整点的阴影面积 (Solar_Area) 数据，
绘制各三棱柱各面阴影面积随时刻的变化曲线，体现日特征
(上午 -> 中午 -> 下午 -> 晚上)。

依赖:
    pip install pandas openpyxl matplotlib numpy

运行:
    python "F:\\南极国创\\我的\\图像生成.py"
"""

import os
import matplotlib.pyplot as plt
import matplotlib.dates as mdates
import numpy as np
import pandas as pd
from datetime import datetime

# ---------- 中文字体 ----------
plt.rcParams["font.sans-serif"] = ["Microsoft YaHei", "SimHei", "DejaVu Sans"]
plt.rcParams["axes.unicode_minus"] = False

# ---------- 配置 ----------
EXCEL_PATH = r"F:\南极国创\我的\测试2.xlsx"
SHEET_NAME = "详细数据"
TARGET_DATE = "2026-01-15"
OUTPUT_DIR = r"F:\南极国创\我的"
OUTPUT_IMG = os.path.join(OUTPUT_DIR, "阴影面积_1月15日_24小时变化.png")

# 日特征时段划分 (用于背景着色)
PERIODS = [
    (0, 6,   "深夜", "#2c3e50"),
    (6, 9,   "上午", "#f39c12"),
    (9, 15,  "中午", "#e67e22"),
    (15, 18, "下午", "#f39c12"),
    (18, 21, "傍晚", "#8e44ad"),
    (21, 24, "夜晚", "#2c3e50"),
]


def load_data(path: str, sheet: str) -> pd.DataFrame:
    """读取 Excel 并做基本类型转换。"""
    df = pd.read_excel(path, sheet_name=sheet, engine="openpyxl")
    df["Date"] = df["Date"].astype(str).str.strip()
    df["Hour"] = pd.to_numeric(df["Hour"], errors="coerce").astype("Int64")
    df["Prism"] = pd.to_numeric(df["Prism"], errors="coerce").astype("Int64")
    df["Face"] = pd.to_numeric(df["Face"], errors="coerce").astype("Int64")
    df["Solar_Area"] = pd.to_numeric(df["Solar_Area"], errors="coerce")
    df["Solar_Elevation"] = pd.to_numeric(df["Solar_Elevation"], errors="coerce")
    return df


def build_hourly(df_date: pd.DataFrame) -> pd.DataFrame:
    """构造 0-23 时完整的阴影面积透视表 (行=小时, 列=Prism-Face)。"""
    sub = df_date[df_date["Hour"].notna()].copy()
    sub["Label"] = sub["Prism"].astype(int).map("P{}".format) + "-F" + sub["Face"].astype(str)
    pivot = sub.pivot_table(index="Hour", columns="Label", values="Solar_Area", aggfunc="first")
    pivot = pivot.reindex(range(0, 24))
    return pivot, sub


def add_period_background(ax, ymax: float):
    """为坐标轴添加日特征时段背景色。"""
    for h0, h1, name, color in PERIODS:
        ax.axvspan(h0, h1, alpha=0.15, color=color)
        ax.text((h0 + h1) / 2, ymax * 0.97 if ymax else 1, name,
                ha="center", va="top", fontsize=9, color=color, alpha=0.9)


def plot_all_in_one(pivot: pd.DataFrame, df_date: pd.DataFrame):
    """六个 Prism-Face 合并到一张图。"""
    fig, ax = plt.subplots(figsize=(14, 7))
    hours = pivot.index.values

    # 太阳高度角作为辅助参考线
    elev = df_date.groupby("Hour")["Solar_Elevation"].first().reindex(range(0, 24))

    palette = plt.cm.tab10(np.linspace(0, 1, pivot.shape[1]))
    for col, color in zip(pivot.columns, palette):
        ax.plot(hours, pivot[col].values, marker="o", linewidth=2,
                markersize=5, label=col, color=color)

    ax2 = ax.twinx()
    ax2.plot(hours, elev.values, "--", color="gold", linewidth=1.5, alpha=0.7, label="太阳高度角")
    ax2.set_ylabel("太阳高度角 (°)", color="gold")
    ax2.tick_params(axis="y", labelcolor="gold")
    ax2.set_ylim(-90, 90)

    ymax = np.nanmax(pivot.values) * 1.1
    add_period_background(ax, ymax)

    ax.set_title(f"{TARGET_DATE} 三棱柱光伏组件各面阴影面积 24 小时变化", fontsize=15, fontweight="bold")
    ax.set_xlabel("时刻 (Hour)")
    ax.set_ylabel("阴影面积 (Solar_Area)")
    ax.set_xticks(range(0, 24))
    ax.set_xlim(0, 24)
    ax.grid(True, linestyle=":", alpha=0.5)
    ax.legend(loc="upper left", ncol=2, fontsize=9, title="Prism-Face")
    ax2.legend(loc="upper right", fontsize=9)

    plt.tight_layout()
    fig.savefig(OUTPUT_IMG, dpi=200, bbox_inches="tight")
    plt.close(fig)
    print(f"[OK] 已保存合并图: {OUTPUT_IMG}")


def plot_per_face(pivot: pd.DataFrame, df_date: pd.DataFrame):
    """每个 Prism-Face 单独一张子图，并标注阴影状态。"""
    cols = list(pivot.columns)
    ncol = 3
    nrow = int(np.ceil(len(cols) / ncol))
    fig, axes = plt.subplots(nrow, ncol, figsize=(16, 4.5 * nrow), sharex=True)
    axes = np.array(axes).reshape(-1)

    elev = df_date.groupby("Hour")["Solar_Elevation"].first().reindex(range(0, 24))
    hours = pivot.index.values

    for i, col in enumerate(cols):
        ax = axes[i]
        vals = pivot[col].values
        ax.plot(hours, vals, "-o", color="#2980b9", linewidth=2, markersize=5)

        # 标注状态 (Night / Self-Shadow / Fully Illuminated / Neighbor-Obstructed)
        sub = df_date[df_date["Prism"].astype(int) == int(col.split("-")[0][1:])]
        sub = sub[sub["Face"].astype(int) == int(col.split("-F")[1])]
        status_map = dict(zip(sub["Hour"], sub["Solar_Status"]))
        for h in hours:
            st = status_map.get(h, "")
            if vals[hours.tolist().index(h)] > 0 and st:
                ax.annotate(st[:6], (h, vals[hours.tolist().index(h)]),
                            textcoords="offset points", xytext=(0, 6),
                            ha="center", fontsize=7, color="#c0392b", rotation=0)

        ymax = np.nanmax(vals) * 1.15 if np.nanmax(vals) > 0 else 1
        add_period_background(ax, ymax)

        ax.set_title(col, fontsize=12, fontweight="bold")
        ax.set_xlim(0, 24)
        ax.set_xticks(range(0, 24, 2))
        ax.grid(True, linestyle=":", alpha=0.5)
        ax.set_ylabel("阴影面积")
        if i >= (nrow - 1) * ncol:
            ax.set_xlabel("时刻 (Hour)")

        # 辅助太阳高度角
        ax2 = ax.twinx()
        ax2.plot(hours, elev.values, "--", color="gold", alpha=0.5, linewidth=1)
        ax2.set_ylim(-90, 90)
        ax2.tick_params(axis="y", labelcolor="gold", labelsize=7)

    for j in range(len(cols), len(axes)):
        axes[j].axis("off")

    fig.suptitle(f"{TARGET_DATE} 各面阴影面积 24 小时日变化 (按 Prism-Face)",
                 fontsize=15, fontweight="bold", y=1.00)
    plt.tight_layout()
    out = os.path.join(OUTPUT_DIR, "阴影面积_1月15日_各面分图.png")
    fig.savefig(out, dpi=200, bbox_inches="tight")
    plt.close(fig)
    print(f"[OK] 已保存分面图: {out}")


def plot_total_area(pivot: pd.DataFrame, df_date: pd.DataFrame):
    """绘制六个面阴影面积总和的 24 小时变化曲线。"""
    fig, ax = plt.subplots(figsize=(14, 7))
    hours = pivot.index.values
    total = pivot.sum(axis=1).values
    max_total = float(np.nanmax(total)) * 1.1 if np.nanmax(total) > 0 else 1.0

    # 时段背景
    add_period_background(ax, max_total)

    # 总面积曲线 + 填充
    ax.plot(hours, total, "-o", color="#c0392b", linewidth=2.5, markersize=6,
            label="六面阴影面积总和")
    ax.fill_between(hours, 0, total, color="#c0392b", alpha=0.18)

    # 峰谷标注
    idx_max = int(np.nanargmax(total))
    idx_min = int(np.nanargmin(total))
    ax.annotate(f"最大值\n{total[idx_max]:.2f} @ {hours[idx_max]:02d}:00",
                xy=(hours[idx_max], total[idx_max]),
                xytext=(hours[idx_max] + 1.5, total[idx_max] * 0.9),
                fontsize=10, color="#c0392b",
                arrowprops=dict(arrowstyle="->", color="#c0392b"))
    ax.annotate(f"最小值\n{total[idx_min]:.2f} @ {hours[idx_min]:02d}:00",
                xy=(hours[idx_min], total[idx_min]),
                xytext=(hours[idx_min] + 1.5, total[idx_min] + max_total * 0.08),
                fontsize=10, color="#27ae60",
                arrowprops=dict(arrowstyle="->", color="#27ae60"))

    # 辅助太阳高度角
    elev = df_date.groupby("Hour")["Solar_Elevation"].first().reindex(range(0, 24))
    ax2 = ax.twinx()
    ax2.plot(hours, elev.values, "--", color="gold", linewidth=1.5, alpha=0.7,
             label="太阳高度角")
    ax2.set_ylabel("太阳高度角 (°)", color="gold")
    ax2.tick_params(axis="y", labelcolor="gold")
    ax2.set_ylim(-90, 90)
    ax2.legend(loc="upper right", fontsize=9)

    ax.set_title(f"{TARGET_DATE} 三棱柱光伏组件六面阴影面积总和 24 小时变化",
                 fontsize=15, fontweight="bold")
    ax.set_xlabel("时刻 (Hour)")
    ax.set_ylabel("阴影面积总和 (六面)")
    ax.set_xticks(range(0, 24))
    ax.set_xlim(0, 24)
    ax.set_ylim(0, max_total)
    ax.grid(True, linestyle=":", alpha=0.5)
    ax.legend(loc="upper left", fontsize=10)

    plt.tight_layout()
    out = os.path.join(OUTPUT_DIR, "阴影面积_1月15日_六面总和.png")
    fig.savefig(out, dpi=200, bbox_inches="tight")
    plt.close(fig)
    print(f"[OK] 已保存六面总和图: {out}")


def print_summary(pivot: pd.DataFrame):
    """打印简要日特征统计。"""
    print("\n=== 1月15日 阴影面积日特征 (Solar_Area) ===")
    print(pivot.round(2).to_string())
    print("\n时段均值:")
    seg = {
        "深夜(0-6)":  range(0, 6),
        "上午(6-9)":  range(6, 9),
        "中午(9-15)": range(9, 15),
        "下午(15-18)":range(15, 18),
        "傍晚(18-21)":range(18, 21),
        "夜晚(21-24)":range(21, 24),
    }
    rows = []
    for name, hrs in seg.items():
        row = {c: float(pivot.loc[list(hrs), c].mean()) for c in pivot.columns}
        row["时段"] = name
        rows.append(row)
    seg_df = pd.DataFrame(rows).set_index("时段")
    print(seg_df.round(2).to_string())


def main():
    if not os.path.exists(EXCEL_PATH):
        raise FileNotFoundError(f"找不到 Excel 文件: {EXCEL_PATH}")

    print(f"读取: {EXCEL_PATH}  工作表: {SHEET_NAME}")
    df = load_data(EXCEL_PATH, SHEET_NAME)
    df_date = df[df["Date"] == TARGET_DATE].copy()
    if df_date.empty:
        raise ValueError(f"未找到 {TARGET_DATE} 的数据，请检查 Date 列格式。")
    print(f"{TARGET_DATE} 共 {len(df_date)} 行记录")

    pivot, sub = build_hourly(df_date)
    print(f"Prism-Face 组合: {list(pivot.columns)}")

    print_summary(pivot)
    plot_all_in_one(pivot, sub)
    plot_per_face(pivot, sub)
    plot_total_area(pivot, sub)
    print("\n全部完成。")


if __name__ == "__main__":
    main()

# -*- coding: utf-8 -*-
"""
1月15日 24 小时 (每10分钟一次) 三棱柱光伏组件阴影面积计算与绘图
================================================================
- 组件: 10 个正三棱柱, 2 行 × 5 列阵列
- 棱柱参数: 底面边长 width=0.998, 高 side_height=1.691, rotation=0
- 横向 (x) 同位点间距 = 5 + 0.998 = 5.998 m
- 纵向 (y) 同位点间距 = 10 m
- 地点: 南极 (-62.12, -58.57), 时区 Etc/GMT+3
- 日期: 2026-01-15, 采样间隔 10 分钟
- 输出: 全日.xlsx + 总阴影面积变化曲线 PNG

依赖:
    pip install pandas numpy openpyxl matplotlib pvlib
    (AngleModule / AssemblyModule / Shade 来自 Solar-master)
"""

import os
import sys
import math
import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
import matplotlib.dates as mdates
from datetime import datetime, timedelta

# ---- 接入 Solar-master 源码 ----
SOLAR_SRC = r"F:\下载\Solar-master\Solar-master\src"
if SOLAR_SRC not in sys.path:
    sys.path.insert(0, SOLAR_SRC)

from AngleModule.AngleHandler import AngleHandler
from AssemblyModule.ComponentsHandler import AngleGenerator
from Shade.ShadeHandler import CalShade

# ---------- 中文字体 ----------
plt.rcParams["font.sans-serif"] = ["Microsoft YaHei", "SimHei", "DejaVu Sans"]
plt.rcParams["axes.unicode_minus"] = False

# ---------- 配置 ----------
LAT = -62.12
LON = -58.57
TIMEZONE = "Etc/GMT+3"
TARGET_DATE = datetime(2026, 1, 15)
BASE_ANGLE = 0          # rotation
WIDTH = 0.998           # 底面边长
SIDE_HEIGHT = 1.691     # 棱柱高
DX = 5.998              # 横向同位点间距 (5 + 0.998)
DY = 10.0               # 纵向同位点间距
SAMPLE_DENSITY = 15     # 采样密度
STEP_MIN = 10           # 时间步长 (分钟)

OUTPUT_DIR = r"F:\南极国创\我的\全日测试"
EXCEL_PATH = os.path.join(OUTPUT_DIR, "全日.xlsx")
IMG_PATH = os.path.join(OUTPUT_DIR, "阴影面积_1月15日_总阴影面积.png")


def build_prisms() -> list:
    """构造 2 行 × 5 列共 10 个棱柱参数 (中心点坐标)。"""
    # 以阵列几何中心为原点
    x_offsets = [(i - 2) * DX for i in range(5)]   # -2DX .. +2DX
    y_offsets = [(j - 0.5) * DY for j in range(2)]  # -0.5DY, +0.5DY
    prisms = []
    for y in y_offsets:
        for x in x_offsets:
            prisms.append({
                "center_x": float(x),
                "center_y": float(y),
                "width": WIDTH,
                "side_height": SIDE_HEIGHT,
                "rotation": BASE_ANGLE,
            })
    return prisms


def compute_one_day(prisms_data: list) -> pd.DataFrame:
    """计算 1月15日 0:00 - 23:50 每 10 分钟一次的阴影数据。"""
    handler = AngleHandler(latitude=LAT, longitude=LON, timeZone=TIMEZONE)
    shading_engine = CalShade()
    prism_gen = AngleGenerator(n=3, base_angle=BASE_ANGLE)
    face_angles = prism_gen.generate()

    results = []
    n_steps = int(24 * 60 / STEP_MIN)
    t0 = TARGET_DATE

    for k in range(n_steps):
        t = t0 + timedelta(minutes=k * STEP_MIN)
        time_str = t.strftime("%Y-%m-%d %H:%M")

        try:
            sol_pos = handler.getAngle(time_str)
            elevation = float(sol_pos["apparent_elevation"].iloc[0])
            azimuth = float(sol_pos["azimuth"].iloc[0])
        except Exception as e:
            print(f"  [警告] getAngle 失败 {time_str}: {e}")
            continue

        # AOI 直接公式计算
        all_aoi = []
        for _ in prisms_data:
            for angle in face_angles:
                if elevation > 0:
                    elev_rad = math.radians(elevation)
                    az_diff_rad = math.radians(azimuth - angle)
                    cos_val = math.cos(elev_rad) * math.cos(az_diff_rad)
                    cos_val = max(-1.0, min(1.0, cos_val))
                    aoi = float(math.degrees(math.acos(cos_val)))
                else:
                    aoi = -1000.0
                all_aoi.append(aoi)

        shadow_results = shading_engine.compute_single_time_shadows(
            prisms_params=prisms_data,
            solar_elevation=elevation,
            solar_azimuth=azimuth,
            incidence_angles=all_aoi,
            sample_density=SAMPLE_DENSITY,
        )

        time_label = t.strftime("%H:%M")
        for i, res in enumerate(shadow_results):
            results.append({
                "Date": t.strftime("%Y-%m-%d"),
                "Time": time_label,
                "Datetime": t.strftime("%Y-%m-%d %H:%M"),
                "Solar_Elevation": round(elevation, 4),
                "Solar_Azimuth": round(azimuth, 4),
                "Prism": res["Prism"],
                "Face": res["Face"],
                "AOI": round(all_aoi[i], 4),
                "Solar_Area": res["Shadow Area (m2)"],
                "Solar_Status": res["Status"],
            })

        if k % 12 == 0:  # 每 2 小时打印一次进度
            print(f"  [{time_str}] elev={elevation:.2f} az={azimuth:.2f} "
                  f"已完成 {k + 1}/{n_steps}")

    return pd.DataFrame(results)


def save_excel(df: pd.DataFrame, path: str):
    os.makedirs(os.path.dirname(path), exist_ok=True)
    with pd.ExcelWriter(path, engine="openpyxl") as w:
        df.to_excel(w, sheet_name="详细数据", index=False)
        # 按时刻聚合的总阴影面积
        total = (df.groupby("Datetime", as_index=False)["Solar_Area"].sum()
                   .rename(columns={"Solar_Area": "Total_Shadow_Area"}))
        total["Solar_Elevation"] = (df.groupby("Datetime", as_index=False)
                                      ["Solar_Elevation"].first()["Solar_Elevation"])
        total.to_excel(w, sheet_name="总阴影面积", index=False)
    print(f"[OK] Excel 已保存: {path}  ({len(df)} 行详细, {len(total)} 行汇总)")


def plot_total_area(path: str, out_img: str):
    """读取 Excel 总阴影面积表, 绘制 1月15日总阴影面积 24 小时变化曲线。"""
    df = pd.read_excel(path, sheet_name="总阴影面积", engine="openpyxl")
    df["Datetime"] = pd.to_datetime(df["Datetime"])
    df = df.sort_values("Datetime").reset_index(drop=True)

    times = df["Datetime"]
    total = df["Total_Shadow_Area"].values
    elev = df["Solar_Elevation"].values

    fig, ax = plt.subplots(figsize=(15, 7))

    # 时段背景
    periods = [
        (0, 6, "深夜", "#2c3e50"),
        (6, 9, "上午", "#f39c12"),
        (9, 15, "中午", "#e67e22"),
        (15, 18, "下午", "#f39c12"),
        (18, 21, "傍晚", "#8e44ad"),
        (21, 24, "夜晚", "#2c3e50"),
    ]
    ymax = float(np.nanmax(total)) * 1.1 if np.nanmax(total) > 0 else 1.0
    base = pd.Timestamp("2026-01-15 00:00")
    for h0, h1, name, color in periods:
        ax.axvspan(base + timedelta(hours=h0),
                   base + timedelta(hours=h1),
                   alpha=0.13, color=color)
        mid = base + timedelta(hours=(h0 + h1) / 2)
        ax.text(mid, ymax * 0.97, name, ha="center", va="top",
                fontsize=10, color=color, alpha=0.9)

    # 总阴影面积曲线 + 填充
    ax.plot(times, total, "-", color="#c0392b", linewidth=2.5,
            marker="o", markersize=4, label="总阴影面积 (10个棱柱 × 3面)")
    ax.fill_between(times, 0, total, color="#c0392b", alpha=0.18)

    # 峰谷标注
    idx_max = int(np.nanargmax(total))
    idx_min_day = None
    day_mask = elev > 0
    if day_mask.any():
        idx_min_day = np.where(day_mask)[0][np.nanargmin(total[day_mask])]

    ax.annotate(f"最大值\n{total[idx_max]:.2f} m^2\n{times[idx_max].strftime('%H:%M')}",
                xy=(times[idx_max], total[idx_max]),
                xytext=(times[idx_max] + timedelta(hours=1), total[idx_max] * 0.9),
                fontsize=10, color="#c0392b",
                arrowprops=dict(arrowstyle="->", color="#c0392b"))

    if idx_min_day is not None:
        ax.annotate(f"白天最小\n{total[idx_min_day]:.2f} m^2\n{times[idx_min_day].strftime('%H:%M')}",
                    xy=(times[idx_min_day], total[idx_min_day]),
                    xytext=(times[idx_min_day] - timedelta(hours=2),
                            total[idx_min_day] + ymax * 0.1),
                    fontsize=10, color="#27ae60",
                    arrowprops=dict(arrowstyle="->", color="#27ae60"))

    # 太阳高度角辅助轴
    ax2 = ax.twinx()
    ax2.plot(times, elev, "--", color="gold", linewidth=1.5, alpha=0.8,
             label="太阳高度角")
    ax2.set_ylabel("太阳高度角 (°)", color="gold")
    ax2.tick_params(axis="y", labelcolor="gold")
    ax2.set_ylim(-90, 90)
    ax2.legend(loc="upper right", fontsize=9)

    ax.set_title("2026-01-15 三棱柱光伏组件阵列 总阴影面积 24 小时变化 (每10分钟)",
                 fontsize=15, fontweight="bold")
    ax.set_xlabel("时刻")
    ax.set_ylabel("总阴影面积 (m^2)")
    ax.set_ylim(0, ymax)
    ax.grid(True, linestyle=":", alpha=0.5)
    ax.legend(loc="upper left", fontsize=10)
    ax.xaxis.set_major_formatter(mdates.DateFormatter("%H:%M"))
    ax.xaxis.set_major_locator(mdates.HourLocator(interval=1))
    ax.xaxis.set_minor_locator(mdates.MinuteLocator(byminute=[0, 30]))
    plt.setp(ax.get_xticklabels(), rotation=30, ha="right")

    plt.tight_layout()
    fig.savefig(out_img, dpi=200, bbox_inches="tight")
    plt.close(fig)
    print(f"[OK] 总阴影面积图已保存: {out_img}")

    # 简要统计
    print("\n=== 2026-01-15 总阴影面积日特征 ===")
    print(f"  全天采样点数: {len(df)}")
    print(f"  全天最大值  : {float(np.nanmax(total)):.2f} m^2  "
          f"@ {times[idx_max].strftime('%H:%M')}")
    print(f"  白天最小值  : {float(total[idx_min_day]):.2f} m^2  "
          f"@ {times[idx_min_day].strftime('%H:%M')}" if idx_min_day else "  (无白天数据)")
    print(f"  全天均值    : {float(np.nanmean(total)):.2f} m^2")
    print(f"  白天均值    : {float(np.nanmean(total[day_mask])):.2f} m^2"
          if day_mask.any() else "")


def main():
    print("=" * 60)
    print("1月15日 24小时 (每10分钟) 阴影面积计算")
    print("=" * 60)
    print(f"地点: lat={LAT}, lon={LON}, tz={TIMEZONE}")
    print(f"棱柱: 2行×5列共10个, width={WIDTH}, height={SIDE_HEIGHT}, "
          f"rotation={BASE_ANGLE}")
    print(f"间距: 横向={DX} m, 纵向={DY} m")

    prisms = build_prisms()
    print(f"棱柱中心坐标:")
    for i, p in enumerate(prisms, 1):
        print(f"  P{i:02d}: ({p['center_x']:.2f}, {p['center_y']:.2f})")

    print("\n[1/2] 计算阴影数据...")
    df = compute_one_day(prisms)
    print(f"\n计算完成, 共 {len(df)} 行 (={len(df)//30} 时刻 × 30 面)")

    print("\n[2/2] 保存 Excel...")
    save_excel(df, EXCEL_PATH)

    print("\n[3/3] 生成总阴影面积图...")
    plot_total_area(EXCEL_PATH, IMG_PATH)

    print("\n全部完成。")


if __name__ == "__main__":
    main()

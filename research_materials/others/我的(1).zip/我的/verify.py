"""验证：去掉射线起点偏移后，11个误差时刻是否与 Solar 完全一致"""
import bpy, sys, math
sys.path.insert(0, r'F:\下载\Solar-master\Solar-master\src')
sys.path.insert(0, r'F:\南极国创\我的')

for obj in list(bpy.data.objects):
    bpy.data.objects.remove(obj, do_unlink=True)
for m in list(bpy.data.meshes):
    bpy.data.meshes.remove(m)

from mathutils import Vector
from mathutils.bvhtree import BVHTree
import pandas as pd
from 测试 import (create_triangular_prism, get_side_face_data,
                  build_side_bvh, generate_face_samples, WIDTH, HEIGHT)

prism_objs = [create_triangular_prism(f"Prism_{i+1}", cx, cy, WIDTH, HEIGHT, 0)
              for i, (cx, cy) in enumerate([(0.0, 0.0), (0.0, 14.98)])]
face_data = [get_side_face_data(o) for o in prism_objs]
bvh_list = [build_side_bvh(o) for o in prism_objs]

df = pd.read_excel(r'F:\南极国创\我的\测试.xlsx', sheet_name='详细数据')
err_rows = df[df['Diff'] != 0]

total_area = WIDTH * HEIGHT
print(f'{"Date":<12}{"Hour":<6}{"Solar":<10}{"原Blender":<12}{"无偏移":<12}{"无偏移-Solar":<14}')
print('-' * 66)

for _, row in err_rows.iterrows():
    elev = row['Solar_Elevation']
    az = row['Solar_Azimuth']
    p_idx = int(row['Prism']) - 1
    f_idx = int(row['Face']) - 1

    if elev <= 0:
        continue

    alt_rad = math.radians(elev)
    az_rad = math.radians(az)
    light_dir = Vector((math.sin(az_rad) * math.cos(alt_rad),
                        math.cos(az_rad) * math.cos(alt_rad),
                        math.sin(alt_rad))).normalized()

    face = face_data[p_idx][f_idx]
    normal = face['normal']
    if normal.dot(light_dir) <= 0:
        continue

    pts = generate_face_samples(face, 15)
    count_with = 0
    count_without = 0
    for pt in pts:
        # 有偏移
        o1 = pt + normal * 0.001
        for other in range(len(bvh_list)):
            if other == p_idx:
                continue
            loc, _, _, _ = bvh_list[other].ray_cast(o1, light_dir)
            if loc is not None:
                count_with += 1
                break
        # 无偏移
        o2 = pt
        for other in range(len(bvh_list)):
            if other == p_idx:
                continue
            loc, _, _, _ = bvh_list[other].ray_cast(o2, light_dir)
            if loc is not None:
                count_without += 1
                break

    area_with = total_area * count_with / 225
    area_without = total_area * count_without / 225
    print(f'{row["Date"]:<12}{int(row["Hour"]):<6}{row["Solar_Area"]:<10.4f}'
          f'{row["Blender_Area"]:<12.4f}{area_without:<12.4f}'
          f'{area_without - row["Solar_Area"]:+.4f}')

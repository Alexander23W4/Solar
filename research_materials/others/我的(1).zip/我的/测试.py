"""
Blender 三棱柱光伏组件阴影面积自动计算
=====================================
- 在 Blender 中建立两个正三棱柱光伏组件
- 对 2026 年每天每个整点，使用射线投射计算每个面的阴影面积
- 与 Solar 项目 (ShadeHandler) 结果对比，输出 MAE / RMSE / MAPE / Bias

运行方式:
    1) 命令行（推荐，后台无界面）:
        blender --background --python "F:\\南极国创\\我的\\测试.py"
    2) 在 Blender GUI 的 Scripting 工作区打开本文件，点击运行

依赖（Blender 自带 Python 环境）:
    pip install pvlib pandas openpyxl numpy
    安装命令示例:
        "C:\\Program Files\\Blender Foundation\\Blender 4.x\\4.x\\python\\bin\\python.exe" -m pip install pvlib pandas openpyxl numpy

坐标系约定（与 Solar 项目一致）:
    +Y = 北, +X = 东, +Z = 上
    方位角: 北为 0°，顺时针为正 (pvlib 约定)
    太阳光方向向量 (从地面指向太阳):
        light_dir = (sin(az)*cos(alt), cos(az)*cos(alt), sin(alt))
"""

import bpy
import bmesh
import math
import sys
import os
from datetime import datetime, timedelta

import mathutils
from mathutils import Vector
from mathutils.bvhtree import BVHTree

# 强制行缓冲，便于后台运行时实时查看进度
try:
    sys.stdout.reconfigure(line_buffering=True)
    sys.stderr.reconfigure(line_buffering=True)
except Exception:
    pass

# 将 Solar 项目源码目录加入 sys.path
SOLAR_SRC = r'F:\下载\Solar-master\Solar-master\src'
if SOLAR_SRC not in sys.path:
    sys.path.insert(0, SOLAR_SRC)

# ======================== 参数配置 ========================
WIDTH = 9.98              # 正三棱柱底面边长
HEIGHT = 11.5             # 棱柱高度
BASE_ANGLE = 0            # 第 1 面法向量方位角（与 Solar 项目 base_angle 一致）
PRISM_CENTERS_XY = [(0.0, 0.0), (0.0, 14.98)]  # 两棱柱 XY 中心，底面贴地 z=0
LAT = -62.12
LON = -58.57
TZ = 'Etc/GMT+3'
YEAR = 2026
SAMPLE_DENSITY = 15       # 采样密度，与 ShadeHandler 默认一致
OUTPUT_XLSX = r'F:\南极国创\我的\测试2.xlsx'

# 快速测试模式：只计算前 N 天（设为 None 则计算全年）
TEST_DAYS = None


# ======================== 场景构建 ========================
def clear_scene():
    """清空场景中所有对象与数据。"""
    for obj in list(bpy.data.objects):
        bpy.data.objects.remove(obj, do_unlink=True)
    for mesh in list(bpy.data.meshes):
        bpy.data.meshes.remove(mesh)
    for light in list(bpy.data.lights):
        bpy.data.lights.remove(light)


def create_triangular_prism(name, center_x, center_y, width, height, rotation_deg):
    """
    创建正三棱柱网格。底面贴地 z=0，顶部 z=height。

    面序号（与 Solar 项目 TriangularPrism 严格一致）:
        Polygon 0 (Face 1): 法向量方位角 = rotation
        Polygon 1 (Face 2): 法向量方位角 = rotation + 120°
        Polygon 2 (Face 3): 法向量方位角 = rotation + 240°
        Polygon 3: 底面 (法向量 -Z)
        Polygon 4: 顶面 (法向量 +Z)
    """
    R = width / math.sqrt(3.0)
    # 三顶点方位角: rotation-60°, rotation+60°, rotation+180°
    angles = [math.radians(rotation_deg - 60.0 + k * 120.0) for k in range(3)]
    verts_2d = [(center_x + R * math.sin(a), center_y + R * math.cos(a)) for a in angles]

    # v0,v1,v2 = 底面; v3,v4,v5 = 顶面
    verts = [(x, y, 0.0) for x, y in verts_2d] + [(x, y, height) for x, y in verts_2d]

    # 侧面（CCW 从外侧看，保证外法向量）
    # Face 1: right=v1, left=v0  → (v1, v0, v3, v4)
    # Face 2: right=v2, left=v1  → (v2, v1, v4, v5)
    # Face 3: right=v0, left=v2  → (v0, v2, v5, v3)
    faces = [
        (1, 0, 3, 4),  # Face 1
        (2, 1, 4, 5),  # Face 2
        (0, 2, 5, 3),  # Face 3
        (0, 2, 1),     # 底面 (法向量 -Z)
        (3, 4, 5),     # 顶面 (法向量 +Z)
    ]

    mesh = bpy.data.meshes.new(name)
    mesh.from_pydata(verts, [], faces)
    mesh.validate(verbose=False)
    mesh.update()
    obj = bpy.data.objects.new(name, mesh)
    bpy.context.collection.objects.link(obj)
    return obj


def get_side_face_data(obj):
    """提取三个侧面的世界坐标顶点、法向量、面积。"""
    mesh = obj.data
    matrix = obj.matrix_world
    side_faces = []
    for i in range(3):
        poly = mesh.polygons[i]
        verts_world = [matrix @ mesh.vertices[v_idx].co for v_idx in poly.vertices]
        normal = (matrix.to_3x3() @ poly.normal).normalized()
        side_faces.append({
            'vertices': verts_world,
            'normal': normal,
            'area': WIDTH * HEIGHT,
        })
    return side_faces


def generate_face_samples(face, density):
    """
    在四边形面上生成 density×density 个采样点（双线性插值）。
    与 Solar 项目 BoundedPlane3D.generate_sample_points 一致:
        u_vals = linspace(0.02, 0.98, density)
        v_vals = linspace(0.02, 0.98, density)
    顶点顺序: p0=右下, p1=左下, p2=左上, p3=右上
        u_vec = p1 - p0 (向左), v_vec = p3 - p0 (向上)
    """
    verts = face['vertices']
    if len(verts) != 4:
        return []

    p0, p1, p2, p3 = verts
    u_vec = p1 - p0
    v_vec = p3 - p0

    if density == 1:
        u_vals = [0.5]
        v_vals = [0.5]
    else:
        step = (0.98 - 0.02) / (density - 1)
        u_vals = [0.02 + i * step for i in range(density)]
        v_vals = [0.02 + i * step for i in range(density)]

    points = []
    for u in u_vals:
        for v in v_vals:
            points.append(p0 + u * u_vec + v * v_vec)
    return points


def build_side_bvh(obj):
    """仅用三个侧面构建 BVH（排除顶/底面，与 Solar 项目一致）。"""
    mesh = obj.data
    matrix = obj.matrix_world
    all_verts = [matrix @ v.co for v in mesh.vertices]
    side_polygons = [list(mesh.polygons[i].vertices) for i in range(3)]
    return BVHTree.FromPolygons(all_verts, side_polygons)


# ======================== 阴影计算 ========================
def compute_blender_shadows(face_data_list, bvh_list,
                            solar_elevation, solar_azimuth,
                            sample_density=15):
    """
    对每个棱柱的每个侧面，用射线投射计算阴影面积。

    规则:
        - 太阳俯仰角 ≤ 0: 全部面为全阴影 (Night)
        - 面法向量 · light_dir ≤ 0: 自阴影 (Self-Shadow, 全阴影)
        - 否则: 采样点射线检测，被相邻棱柱遮挡的比例 × 面积 = 阴影面积
    """
    total_area = WIDTH * HEIGHT
    n_prisms = len(face_data_list)

    # 夜间
    if solar_elevation <= 0:
        results = []
        for p_idx in range(n_prisms):
            for f_idx in range(3):
                results.append({
                    'Prism': p_idx + 1,
                    'Face': f_idx + 1,
                    'Blender_Area': round(total_area, 4),
                    'Blender_Status': 'Night'
                })
        return results

    # 太阳光方向（从采样点指向太阳）
    alt_rad = math.radians(solar_elevation)
    az_rad = math.radians(solar_azimuth)
    light_dir = Vector((
        math.sin(az_rad) * math.cos(alt_rad),
        math.cos(az_rad) * math.cos(alt_rad),
        math.sin(alt_rad),
    )).normalized()

    results = []
    for p_idx in range(n_prisms):
        for f_idx in range(3):
            face = face_data_list[p_idx][f_idx]
            normal = face['normal']

            # 自阴影：面背对太阳
            if normal.dot(light_dir) <= 0:
                results.append({
                    'Prism': p_idx + 1,
                    'Face': f_idx + 1,
                    'Blender_Area': round(total_area, 4),
                    'Blender_Status': 'Self-Shadow'
                })
                continue

            sample_pts = generate_face_samples(face, sample_density)
            if not sample_pts:
                results.append({
                    'Prism': p_idx + 1,
                    'Face': f_idx + 1,
                    'Blender_Area': 0.0,
                    'Blender_Status': 'Fully Illuminated'
                })
                continue

            shadow_count = 0
            for pt in sample_pts:
                # BVH 已排除自身棱柱，无需偏移
                origin = pt
                # 仅检测其它棱柱
                for other_idx in range(len(bvh_list)):
                    if other_idx == p_idx:
                        continue
                    loc, norm, idx, dist = bvh_list[other_idx].ray_cast(origin, light_dir)
                    if loc is not None:
                        shadow_count += 1
                        break

            shadow_ratio = shadow_count / len(sample_pts)
            shadow_area = total_area * shadow_ratio
            results.append({
                'Prism': p_idx + 1,
                'Face': f_idx + 1,
                'Blender_Area': round(shadow_area, 4),
                'Blender_Status': 'Neighbor-Obstructed' if shadow_ratio > 0
                                  else 'Fully Illuminated'
            })
    return results


# ======================== Excel 输出与误差指标 ========================
def write_excel_output(results, output_path):
    """写 Excel: 详细数据 + 误差指标。"""
    try:
        import pandas as pd
        import numpy as np
    except ImportError:
        print("[警告] pandas/numpy 不可用，输出 CSV")
        write_csv_fallback(results, output_path.replace('.xlsx', '.csv'))
        return

    df = pd.DataFrame(results)
    df['Diff'] = df['Blender_Area'] - df['Solar_Area']

    # 按棱柱×面分组计算指标
    metrics_list = []
    for (prism, face), group in df.groupby(['Prism', 'Face']):
        m = _compute_metrics(group['Diff'].values, group['Solar_Area'].values)
        m.update({'Prism': prism, 'Face': face, 'Count': len(group)})
        metrics_list.append(m)

    # 总体指标
    m_all = _compute_metrics(df['Diff'].values, df['Solar_Area'].values)
    m_all.update({'Prism': 'All', 'Face': 'All', 'Count': len(df)})
    metrics_list.append(m_all)

    metrics_df = pd.DataFrame(metrics_list)[
        ['Prism', 'Face', 'Count', 'MAE', 'RMSE', 'MAPE(%)', 'Bias']
    ]

    try:
        with pd.ExcelWriter(output_path, engine='openpyxl') as writer:
            df.to_excel(writer, sheet_name='详细数据', index=False)
            metrics_df.to_excel(writer, sheet_name='误差指标', index=False)
        print(f"\n已保存 {len(df)} 行详细数据 + {len(metrics_df)} 行指标至:")
        print(f"  {output_path}")
    except ImportError:
        print("[警告] openpyxl 不可用，输出 CSV")
        write_csv_fallback(results, output_path.replace('.xlsx', '.csv'))
        return

    # 控制台打印指标摘要
    print("\n" + "=" * 60)
    print("误差指标汇总")
    print("=" * 60)
    print(metrics_df.to_string(index=False))


def _compute_metrics(diff, solar):
    """计算 MAE, RMSE, MAPE, Bias。"""
    import numpy as np
    diff = np.asarray(diff, dtype=float)
    solar = np.asarray(solar, dtype=float)
    mae = float(np.mean(np.abs(diff)))
    rmse = float(np.sqrt(np.mean(diff ** 2)))
    non_zero = np.abs(solar) > 1e-6
    if non_zero.sum() > 0:
        mape = float(np.mean(np.abs(diff[non_zero]) / np.abs(solar[non_zero])) * 100)
    else:
        mape = float('nan')
    bias = float(np.mean(diff))
    return {
        'MAE': round(mae, 4),
        'RMSE': round(rmse, 4),
        'MAPE(%)': round(mape, 4) if not math.isnan(mape) else 'N/A',
        'Bias': round(bias, 4),
    }


def write_csv_fallback(results, output_path):
    import csv
    if not results:
        return
    keys = list(results[0].keys())
    with open(output_path, 'w', encoding='utf-8-sig', newline='') as f:
        writer = csv.DictWriter(f, fieldnames=keys)
        writer.writeheader()
        writer.writerows(results)
    print(f"已保存 {len(results)} 行至 {output_path}")


# ======================== 主流程 ========================
def main():
    print("=" * 70)
    print("Blender 三棱柱光伏组件阴影面积计算 (2026 全年每整点)")
    print("=" * 70)
    print(f"位置: lat={LAT}, lon={LON}, tz={TZ}")
    print(f"棱柱: width={WIDTH}, height={HEIGHT}, base_angle={BASE_ANGLE}")
    print(f"中心: {PRISM_CENTERS_XY}")
    print(f"采样密度: {SAMPLE_DENSITY}×{SAMPLE_DENSITY} = {SAMPLE_DENSITY**2} 点/面")

    # ---------- 1. 计算 Solar 项目结果 ----------
    print("\n[1/4] 计算 Solar 项目阴影结果...")
    from test import compute_solar_shadows_2026
    solar_df = compute_solar_shadows_2026(
        lat=LAT, lon=LON, timezone=TZ,
        base_angle=BASE_ANGLE, year=YEAR,
        sample_density=SAMPLE_DENSITY, verbose=True,
        max_days=TEST_DAYS,
    )
    print(f"  Solar 结果: {len(solar_df)} 行, 覆盖 {solar_df['Date'].nunique()} 天")

    # ---------- 2. 构建 Blender 场景 ----------
    print("\n[2/4] 构建 Blender 场景...")
    clear_scene()
    prism_objs = []
    for i, (cx, cy) in enumerate(PRISM_CENTERS_XY):
        obj = create_triangular_prism(f"Prism_{i+1}", cx, cy,
                                      WIDTH, HEIGHT, BASE_ANGLE)
        prism_objs.append(obj)
        print(f"  创建 {obj.name} 中心 XY=({cx}, {cy})")

    # 预计算面数据与 BVH（棱柱不动，复用）
    face_data_list = [get_side_face_data(obj) for obj in prism_objs]
    bvh_list = [build_side_bvh(obj) for obj in prism_objs]

    # ---------- 3. 逐时刻计算 Blender 阴影 ----------
    print("\n[3/4] 计算 Blender 阴影面积...")
    solar_groups = {}
    for _, row in solar_df.iterrows():
        key = (row['Date'], int(row['Hour']))
        solar_groups.setdefault(key, []).append(row.to_dict())

    all_results = []
    total = len(solar_groups)
    for idx, ((date_str, hour), solar_rows) in enumerate(sorted(solar_groups.items())):
        if idx % 200 == 0:
            print(f"  进度: {idx}/{total}  ({date_str} {hour:02d}:00)")

        elevation = float(solar_rows[0]['Solar_Elevation'])
        azimuth = float(solar_rows[0]['Solar_Azimuth'])

        blender_results = compute_blender_shadows(
            face_data_list, bvh_list, elevation, azimuth, SAMPLE_DENSITY
        )

        for s_row in solar_rows:
            p = int(s_row['Prism'])
            f = int(s_row['Face'])
            b_row = next(b for b in blender_results
                         if b['Prism'] == p and b['Face'] == f)
            all_results.append({
                'Date': date_str,
                'Hour': hour,
                'Solar_Elevation': elevation,
                'Solar_Azimuth': azimuth,
                'Prism': p,
                'Face': f,
                'AOI': float(s_row['AOI']),
                'Solar_Area': float(s_row['Solar_Area']),
                'Solar_Status': s_row['Solar_Status'],
                'Blender_Area': b_row['Blender_Area'],
                'Blender_Status': b_row['Blender_Status'],
            })

    # ---------- 4. 输出 Excel ----------
    print(f"\n[4/4] 写入 Excel: {OUTPUT_XLSX}")
    write_excel_output(all_results, OUTPUT_XLSX)
    print("\n完成!")


if __name__ == "__main__":
    main()

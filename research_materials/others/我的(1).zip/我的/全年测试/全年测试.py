# -*- coding: utf-8 -*-
"""
2026 年每月 15 日 整点阴影面积计算与月特征绘图
================================================
- 组件: 10 个正三棱柱, 2 行 × 5 列阵列 (同全日测试配置)
- 棱柱参数: width=0.998, side_height=1.691, rotation=0
- 横向间距 5.998 m, 纵向 10 m
- 地点: 南极 (-62.12, -58.57), 时区 Etc/GMT+3
- 采样: 2026 年 1~12 月每月 15 日, 每个整点 (0:00~23:00), 共 12×24=288 时刻
- 输出: 全年测试.xlsx (详细数据 + 月汇总) + 12 个月均值折线图

月特征定义:
    每个整点 -> 30 个面阴影面积求和 (该时刻总阴影面积)
    该日 24 个整点总阴影面积 -> 求平均, 作为当月特征值
    12 个月共 12 个点绘制曲线

依赖:
    pip install pandas numpy openpyxl matplotlib pvlib
"""

import os
import sys
import io
import math
import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
from datetime import datetime, timedelta

sys.stdout = io.TextIOWrapper(sys.stdout.buffer, encoding="utf-8")

# ---- 接入 Solar-master 源码 ----
SOLAR_SRC = r"F:\下载\Solar-master\Solar-master\src"
if SOLAR_SRC not in sys.path:
    sys.path.insert(0, SOLAR_SRC)

from AngleModule.AngleHandler import AngleHandler
from AssemblyModule.ComponentsHandler import AngleGenerator
from Shade.ShadeHandler import CalShade

# ---------- 中文字体 ----------
plt.rcParams["font.sans-serif"] = ["Microsoft YaHei", "SimHei", "DejaVu Sans"]
plt.rcParams["axes.unicode_minus"] = False

# ---------- 配置 ----------
LAT = -62.12
LON = -58.57
TIMEZONE = "Etc/GMT+3"
YEAR = 2026
MONTH_DAYS = [(m, 15) for m in range(1, 13)]
BASE_ANGLE = 0
WIDTH = 0.998
SIDE_HEIGHT = 1.691
DX = 5.998
DY = 10.0
SAMPLE_DENSITY = 15

OUTPUT_DIR = r"F:\南极国创\我的\全年测试"
EXCEL_PATH = os.path.join(OUTPUT_DIR, "全年测试.xlsx")
IMG_PATH = os.path.join(OUTPUT_DIR, "月特征_2026各月15日平均总阴影面积.png")


def build_prisms() -> list:
    x_offsets = [(i - 2) * DX for i in range(5)]
    y_offsets = [(j - 0.5) * DY for j in range(2)]
    prisms = []
    for y in y_offsets:
        for x in x_offsets:
            prisms.append({
                "center_x": float(x),
                "center_y": float(y),
                "width": WIDTH,
                "side_height": SIDE_HEIGHT,
                "rotation": BASE_ANGLE,
            })
    return prisms


def compute_month_15th(prisms_data: list) -> pd.DataFrame:
    """计算 12 个月每月 15 日 24 个整点的阴影数据。"""
    handler = AngleHandler(latitude=LAT, longitude=LON, timeZone=TIMEZONE)
    shading_engine = CalShade()
    prism_gen = AngleGenerator(n=3, base_angle=BASE_ANGLE)
    face_angles = prism_gen.generate()

    results = []
    for month, day in MONTH_DAYS:
        for hour in range(24):
            t = datetime(YEAR, month, day, hour, 0)
            time_str = t.strftime("%Y-%m-%d %H:%M")

            try:
                sol_pos = handler.getAngle(time_str)
                elevation = float(sol_pos["apparent_elevation"].iloc[0])
                azimuth = float(sol_pos["azimuth"].iloc[0])
            except Exception as e:
                print(f"  [警告] getAngle 失败 {time_str}: {e}")
                continue

            all_aoi = []
            for _ in prisms_data:
                for angle in face_angles:
                    if elevation > 0:
                        elev_rad = math.radians(elevation)
                        az_diff_rad = math.radians(azimuth - angle)
                        cos_val = math.cos(elev_rad) * math.cos(az_diff_rad)
                        cos_val = max(-1.0, min(1.0, cos_val))
                        aoi = float(math.degrees(math.acos(cos_val)))
                    else:
                        aoi = -1000.0
                    all_aoi.append(aoi)

            shadow_results = shading_engine.compute_single_time_shadows(
                prisms_params=prisms_data,
                solar_elevation=elevation,
                solar_azimuth=azimuth,
                incidence_angles=all_aoi,
                sample_density=SAMPLE_DENSITY,
            )

            for i, res in enumerate(shadow_results):
                results.append({
                    "Month": month,
                    "Date": t.strftime("%Y-%m-%d"),
                    "Hour": hour,
                    "Solar_Elevation": round(elevation, 4),
                    "Solar_Azimuth": round(azimuth, 4),
                    "Prism": res["Prism"],
                    "Face": res["Face"],
                    "AOI": round(all_aoi[i], 4),
                    "Solar_Area": res["Shadow Area (m2)"],
                    "Solar_Status": res["Status"],
                })

        print(f"  [完成] {YEAR}-{month:02d}-15  24 个整点")

    return pd.DataFrame(results)


def build_monthly_summary(df: pd.DataFrame) -> pd.DataFrame:
    """
    月特征:
      1) 每个整点 30 面阴影面积求和 -> 当时刻总阴影面积
      2) 当日 24 个整点总阴影面积求平均 -> 当月特征值
    """
    hourly_total = (df.groupby(["Month", "Date", "Hour"], as_index=False)
                      ["Solar_Area"].sum()
                      .rename(columns={"Solar_Area": "Hourly_Total_Area"}))
    elev_first = (df.groupby(["Month", "Date", "Hour"], as_index=False)
                    ["Solar_Elevation"].first())
    hourly_total["Solar_Elevation"] = elev_first["Solar_Elevation"]

    monthly = (hourly_total.groupby("Month", as_index=False)
               .agg(Monthly_Mean_Area=("Hourly_Total_Area", "mean"),
                    Daily_Max_Area=("Hourly_Total_Area", "max"),
                    Daily_Min_Area=("Hourly_Total_Area", "min"),
                    Day_Max_Elev=("Solar_Elevation", "max")))
    monthly["Month_Label"] = monthly["Month"].apply(lambda m: f"{YEAR}-{m:02d}-15")
    return monthly, hourly_total


def save_excel(df: pd.DataFrame, monthly: pd.DataFrame,
               hourly_total: pd.DataFrame, path: str):
    os.makedirs(os.path.dirname(path), exist_ok=True)
    with pd.ExcelWriter(path, engine="openpyxl") as w:
        df.to_excel(w, sheet_name="详细数据", index=False)
        hourly_total.to_excel(w, sheet_name="整点总阴影面积", index=False)
        monthly.to_excel(w, sheet_name="月特征汇总", index=False)
    print(f"[OK] Excel 已保存: {path}")
    print(f"     详细数据 {len(df)} 行, 整点汇总 {len(hourly_total)} 行, "
          f"月特征 {len(monthly)} 行")


def plot_monthly(monthly: pd.DataFrame, hourly_total: pd.DataFrame, out_img: str):
    months = monthly["Month"].values
    mean_area = monthly["Monthly_Mean_Area"].values
    max_area = monthly["Daily_Max_Area"].values
    min_area = monthly["Daily_Min_Area"].values
    max_elev = monthly["Day_Max_Elev"].values

    fig, ax = plt.subplots(figsize=(14, 7))

    ax.plot(months, mean_area, "-o", color="#c0392b", linewidth=2.5,
            markersize=9, label="当月15日日均总阴影面积", zorder=3)
    ax.fill_between(months, min_area, max_area, color="#c0392b", alpha=0.15,
                    label="当日整点总阴影面积范围 [min, max]")

    for m, v in zip(months, mean_area):
        ax.annotate(f"{v:.0f}", (m, v), textcoords="offset points",
                    xytext=(0, 10), ha="center", fontsize=9,
                    color="#c0392b", fontweight="bold")

    ax2 = ax.twinx()
    ax2.plot(months, max_elev, "--s", color="gold", linewidth=1.8,
             markersize=7, alpha=0.85, label="当日最高太阳高度角")
    ax2.set_ylabel("太阳高度角 (°)", color="goldenrod")
    ax2.tick_params(axis="y", labelcolor="goldenrod")
    ax2.set_ylim(-90, 90)
    ax2.legend(loc="upper right", fontsize=9)

    ax.set_title(f"{YEAR} 年各月 15 日 三棱柱光伏阵列 总阴影面积月特征"
                 f" (10个棱柱 × 3面, 每个整点求和后日均)",
                 fontsize=14, fontweight="bold")
    ax.set_xlabel("月份")
    ax.set_ylabel("总阴影面积 (m^2)")
    ax.set_xticks(range(1, 13))
    ax.set_xticklabels([f"{m}月" for m in range(1, 13)])
    ax.set_xlim(0.5, 12.5)
    ax.grid(True, linestyle=":", alpha=0.5)
    ax.legend(loc="upper left", fontsize=10)

    plt.tight_layout()
    fig.savefig(out_img, dpi=200, bbox_inches="tight")
    plt.close(fig)
    print(f"[OK] 月特征图已保存: {out_img}")

    print("\n=== 2026 各月 15 日 总阴影面积月特征 ===")
    print(f"{'月份':<6}{'日均(m^2)':<14}{'日内最大':<14}{'日内最小':<14}{'最高高度角':<12}")
    for _, row in monthly.iterrows():
        print(f"{int(row['Month']):<6}{row['Monthly_Mean_Area']:<14.2f}"
              f"{row['Daily_Max_Area']:<14.2f}{row['Daily_Min_Area']:<14.2f}"
              f"{row['Day_Max_Elev']:<12.2f}")


def main():
    print("=" * 60)
    print(f"{YEAR} 年各月 15 日 整点阴影面积计算")
    print("=" * 60)
    print(f"地点: lat={LAT}, lon={LON}, tz={TIMEZONE}")
    print(f"棱柱: 2行×5列共10个, width={WIDTH}, height={SIDE_HEIGHT}, "
          f"rotation={BASE_ANGLE}")
    print(f"间距: 横向={DX} m, 纵向={DY} m")
    print(f"采样: 12 个月 × 24 整点 = 288 时刻, 每时刻 30 面 = 8640 行\n")

    prisms = build_prisms()
    print("[1/3] 计算各月 15 日整点阴影...")
    df = compute_month_15th(prisms)
    print(f"\n计算完成, 共 {len(df)} 行")

    print("\n[2/3] 汇总并保存 Excel...")
    monthly, hourly_total = build_monthly_summary(df)
    save_excel(df, monthly, hourly_total, EXCEL_PATH)

    print("\n[3/3] 生成月特征图...")
    plot_monthly(monthly, hourly_total, IMG_PATH)

    print("\n全部完成。")


if __name__ == "__main__":
    main()
